# services.py
def generate_assignment(topic):
    return f"📘 Mustaqil ish:\nMavzu: {topic}\n\n1. Kirish\n2. Asosiy qism\n3. Xulosa\n4. Foydalanilgan adabiyotlar"

def generate_business_card(topic):
    return f"💼 Vizitka dizayni uchun shablon tayyorlandi:\nIsm: {topic}\nLavozim: Dizayner\nTelefon: +998 90 123 45 67\nEmail: info@example.com"

def generate_course_outline(topic):
    return f"🎓 Video kurs:\nKurs mavzusi: {topic}\n\n1. Kirish\n2. Nazariy qism\n3. Amaliyot\n4. Testlar\n5. Yakuniy imtihon"

def generate_invite(topic):
    return f"💌 Taklifnoma:\nHurmatli {topic} sizni to‘yimizga taklif qilamiz!\nSana: 12.12.2025\nManzil: Toshkent shahri, Navro‘z ko‘chasi 45-uy"