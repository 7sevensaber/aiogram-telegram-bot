AI Xizmat Bot (O'zbek tilida)

1. `main.py` — Telegram bot kodi
2. `services.py` — Xizmatlarni ishlab beruvchi AI-like funksiyalar
3. Bot token allaqachon o‘rnatilgan
4. Ishga tushirish uchun:

$ pip install -r requirements.txt
$ python main.py

5. Hozircha Click/Payme integratsiyasi yo‘q — keyin qo‘shiladi.